# Custom STM32F411RET6 Arduino variant — reviewed draft

This is a board-specific variant folder for the STM32duino core, not a replacement for the whole official core.

## Requested header
- 7 digital GPIO: D0–D6
- 7 ADC inputs: A0–A6 (also Arduino pin indices D7–D13)
- 4 PWM outputs: D14–D17
- power: 2 GND, 1 3V3, 1 5V (PCB nets, not GPIOs)

## Proposed internal connections
- ESP32-C3 UART: PA2 = STM32 TX / ESP32 RX; PA3 = STM32 RX / ESP32 TX
- OLED I2C1: PB8 = SCL; PB9 = SDA
- ADC: PA0, PA1, PC0, PC1, PC2, PC3, PC4
- PWM: PA5, PA6, PA7, PB0

## Before use
This draft has not been compiled against the user's installed core/toolchain. GPIO assignments must match the actual schematic. The built-in LED pin is not known, so `LED_BUILTIN` remains `PNUM_NOT_DEFINED`. Do not replace shared core-wide files. See `INSTALL_AND_VALIDATION.txt`.
