/*
 * Custom STM32F411RET6 Arduino variant.
 * D0-D6: digital header; A0-A6: analog header; D14-D17: PWM header.
 * GPIO assignments are proposals and must match the PCB schematic.
 */
#include "pins_arduino.h"

const PinName digitalPin[] = {
  PB_2,   // D0
  PB_10,  // D1
  PB_12,  // D2
  PB_13,  // D3
  PB_14,  // D4
  PB_15,  // D5
  PC_10,  // D6
  PA_0,   // D7 / A0
  PA_1,   // D8 / A1
  PC_0,   // D9 / A2
  PC_1,   // D10 / A3
  PC_2,   // D11 / A4
  PC_3,   // D12 / A5
  PC_4,   // D13 / A6
  PA_5,   // D14 / PWM0
  PA_6,   // D15 / PWM1
  PA_7,   // D16 / PWM2
  PB_0,   // D17 / PWM3
  PA_2,   // D18 / internal USART2 TX
  PA_3,   // D19 / internal USART2 RX
  PA_4,   // D20 / internal SPI1 SS
  PB_8,   // D21 / internal I2C1 SCL
  PB_9    // D22 / internal I2C1 SDA
};

const pin_size_t analogInputPin[] = {
  7,  // A0 = PA0 / ADC1_IN0
  8,  // A1 = PA1 / ADC1_IN1
  9,  // A2 = PC0 / ADC1_IN10
  10, // A3 = PC1 / ADC1_IN11
  11, // A4 = PC2 / ADC1_IN12
  12, // A5 = PC3 / ADC1_IN13
  13  // A6 = PC4 / ADC1_IN14
};
