#pragma once

/* Arduino pin number aliases for the custom header. */
#define PB2   0
#define PB10  1
#define PB12  2
#define PB13  3
#define PB14  4
#define PB15  5
#define PC10  6
#define PA0   7
#define PA1   8
#define PC0   9
#define PC1   10
#define PC2   11
#define PC3   12
#define PC4   13
#define PA5   14
#define PA6   15
#define PA7   16
#define PB0   17
#define PA2   18
#define PA3   19
#define PA4   20
#define PB8   21
#define PB9   22

#define NUM_DIGITAL_PINS 23
#define NUM_ANALOG_INPUTS 7

/* Set LED_BUILTIN to the correct Arduino pin once PCB LED GPIO is known. */
#ifndef LED_BUILTIN
#define LED_BUILTIN PNUM_NOT_DEFINED
#endif
#ifndef USER_BTN
#define USER_BTN PNUM_NOT_DEFINED
#endif

#ifndef PIN_SPI_SS
#define PIN_SPI_SS PA4
#endif
#ifndef PIN_SPI_MOSI
#define PIN_SPI_MOSI PA7
#endif
#ifndef PIN_SPI_MISO
#define PIN_SPI_MISO PA6
#endif
#ifndef PIN_SPI_SCK
#define PIN_SPI_SCK PA5
#endif

#ifndef PIN_WIRE_SDA
#define PIN_WIRE_SDA PB9
#endif
#ifndef PIN_WIRE_SCL
#define PIN_WIRE_SCL PB8
#endif

#ifndef SERIAL_UART_INSTANCE
#define SERIAL_UART_INSTANCE 2
#endif
#ifndef PIN_SERIAL_TX
#define PIN_SERIAL_TX PA2
#endif
#ifndef PIN_SERIAL_RX
#define PIN_SERIAL_RX PA3
#endif
