STM32 Virtual Lab v2 - Custom F411RET6 (Tinkercad-style)
Open index.html in Chrome/Edge (double-click). Keep pcb_gerber_preview.svg beside it for the PCB view button.

1. Pick "Load example..." (top) or drag parts from the left list onto the canvas.
2. Wire: click a board pin, then click a part terminal (or another pin). Click a wire to delete it.
3. Edit the Arduino code at the bottom, press Start Simulation. Serial Monitor is bottom right.
4. Click a part to change sensor values (light, distance, temperature...) live.

Pin numbering follows your variant.h: D0-D6=0-6, A0-A6=7-13, PWM0-3=14-17. LED_BUILTIN is undefined (as in your variant).
This runs an Arduino C++ subset in the browser; it is not the real GCC compiler or an MCU emulator.

--- v2.2: BoardConnectivity library (ESP32-C3 SuperMini Wi-Fi + BLE) ---
* The board's ESP32-C3 is built in, so there is nothing to wire. Add  #include <BoardConnectivity.h>  to your sketch
  (without it the simulator reports "'BoardConnectivity' was not declared", like the real compiler).
* Click "Libraries" above the code box for the function list, an Insert #include button and downloads of the real
  library files (also in libraries/BoardConnectivity/ for the Arduino IDE).
* The ESP32 panel (bottom right) shows Wi-Fi/BLE state, the UART traffic, a virtual phone for BLE, and the list of
  virtual Wi-Fi networks (ssid,password per line). Untick "powered" to see what a dead ESP32 looks like.
* Three new examples: Wi-Fi connect + status, BLE phone controls LED, Wi-Fi + BLE scan.
* The reply text of the virtual ESP32 (OK|..., WIFI|CONNECTED|..., NO_DATA) is an assumption: edit espHandle() in
  index.html so it matches your real ESP32 firmware.
